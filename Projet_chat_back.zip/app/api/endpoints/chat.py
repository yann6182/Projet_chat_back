# app/api/endpoints/chat.py
from fastapi import APIRouter, HTTPException, Depends
from typing import List
from sqlalchemy.orm import Session
from app.schemas.chat import ChatRequest, ChatResponse
from app.schemas.schema import ConversationSchema, ConversationWithHistory
from app.models.model import Conversation, User

from app.db.database import get_db
from app.services.chat_service import ChatService

router = APIRouter(prefix="/api/chat", tags=["chat"])
chat_service = ChatService()

@router.post("/query", response_model=ChatResponse)
async def process_query(request: ChatRequest):
    """
    Traite une requête utilisateur et génère une réponse juridique.
    Un nouveau conversation_id est généré automatiquement.
    """
    try:
        response = await chat_service.process_query(request)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history/{conversation_id}")
async def get_conversation_history(conversation_id: str):
    """
    Récupère l'historique d'une conversation.
    """
    history = chat_service.get_conversation_history(conversation_id)
    if not history:
        raise HTTPException(status_code=404, detail="Conversation non trouvée")
    return {"conversation_id": conversation_id, "history": history}

@router.delete("/history/{conversation_id}")
async def clear_conversation(conversation_id: str):
    """
    Efface l'historique d'une conversation.
    """
    success = chat_service.clear_conversation(conversation_id)
    if not success:
        raise HTTPException(status_code=404, detail="Conversation non trouvée")
    return {"message": "Conversation effacée avec succès"}
@router.post("/continue/{conversation_id}", response_model=ChatResponse)
async def continue_conversation(conversation_id: str, request: ChatRequest):
    """
    Continue une conversation existante identifiée par son ID.
    """
    try:
        # Passez le conversation_id comme paramètre séparé
        response = await chat_service.process_query(request, conversation_id=conversation_id)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
@router.get("/conversations", response_model=List[ConversationSchema])
def get_all_conversations(db: Session = Depends(get_db)):
    """
    Récupère toutes les conversations avec leur historique.
    """
    try:
        conversations = db.query(Conversation).all()
        return conversations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de la récupération des conversations: {str(e)}")

@router.get("/conversations/{user_id}", response_model=List[ConversationSchema])
def get_user_conversations(user_id: int, db: Session = Depends(get_db)):
    """
    Récupère toutes les conversations d'un utilisateur spécifique.
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    
    try:
        conversations = db.query(Conversation).filter(Conversation.user_id == user_id).all()
        return conversations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de la récupération des conversations: {str(e)}")

@router.get("/conversations/detail/{conversation_id}", response_model=ConversationWithHistory)
def get_conversation_with_history(conversation_id: int, db: Session = Depends(get_db)):
    """
    Récupère une conversation spécifique avec tout son historique de questions et réponses.
    """
    conversation = db.query(Conversation).filter(Conversation.id == conversation_id).first()
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation non trouvée")
    
    
    return conversation
@router.get("/conversations/category/{category}", response_model=List[ConversationSchema])
def get_conversations_by_category(category: str, db: Session = Depends(get_db)):
    """
    Récupère toutes les conversations d'une catégorie spécifique.
    """
    try:
        conversations = db.query(Conversation).filter(Conversation.category == category).all()
        return conversations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de la récupération des conversations: {str(e)}")

@router.get("/conversations/user/{user_id}/category/{category}", response_model=List[ConversationSchema])
def get_user_conversations_by_category(user_id: int, category: str, db: Session = Depends(get_db)):
    """
    Récupère toutes les conversations d'un utilisateur pour une catégorie spécifique.
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    
    try:
        conversations = db.query(Conversation).filter(
            Conversation.user_id == user_id,
            Conversation.category == category
        ).all()
        return conversations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de la récupération des conversations: {str(e)}")
@router.get("/conversations/user/{user_id}/statistics")
def get_user_conversation_statistics(user_id: int, db: Session = Depends(get_db)):
    """
    Récupère des statistiques sur les conversations de l'utilisateur par catégorie.
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    
    # Récupérer le nombre de conversations par catégorie
    from sqlalchemy import func
    
    stats = db.query(Conversation.category, func.count(Conversation.id))\
             .filter(Conversation.user_id == user_id)\
             .group_by(Conversation.category)\
             .all()
             
    # Convertir en dictionnaire
    statistics = {category: count for category, count in stats}
    
    # Ajouter le nombre total de conversations
    total_count = sum(statistics.values())
    
    return {
        "user_id": user_id,
        "total_conversations": total_count,
        "by_category": statistics
    }