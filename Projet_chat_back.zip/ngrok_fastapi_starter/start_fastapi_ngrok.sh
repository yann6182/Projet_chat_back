#!/bin/bash

# Lancer FastAPI
echo "🚀 Lancement de l'API FastAPI sur http://localhost:8000 ..."
uvicorn app.main:app --host 0.0.0.0 --port 8000 &

# Attendre quelques secondes
sleep 5

# Lancer Ngrok
echo "🌍 Exposition via Ngrok..."
ngrok http 8000